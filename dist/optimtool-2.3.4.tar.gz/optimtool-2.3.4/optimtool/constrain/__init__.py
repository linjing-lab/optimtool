from optimtool.constrain import equal
from optimtool.constrain import unequal
from optimtool.constrain import mixequal