from optimtool.example import Lasso
from optimtool.example import WanYuan